const Menu3 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu3 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu3;
