const Menu1 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu1 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu1;
