const Menu222 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu222 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu222;
