const Menu21 = () => {
	return (
		<div className="card content-box">
			<span className="text">Menu21 🍓🍇🍈🍉</span>
		</div>
	);
};

export default Menu21;
