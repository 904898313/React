import "./index.less";

const BatchImport = () => {
	return (
		<div className="card content-box">
			<span className="text">BatchImport 🍓🍇🍈🍉</span>
		</div>
	);
};

export default BatchImport;
