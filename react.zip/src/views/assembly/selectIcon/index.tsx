import "./index.less";

const SelectIcon = () => {
	return (
		<div className="card content-box">
			<span className="text">SelectIcon 🍓🍇🍈🍉</span>
		</div>
	);
};

export default SelectIcon;
