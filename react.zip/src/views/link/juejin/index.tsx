const Juejin = () => {
	return (
		<div className="card content-box">
			<span className="text">
				掘金文档：
				<a href="https://juejin.cn/user/3263814531551816/posts" target="_blank" rel="noreferrer">
					https://juejin.cn/user/3263814531551816/posts
				</a>{" "}
				🍒🍉🍊
			</span>
		</div>
	);
};

export default Juejin;
