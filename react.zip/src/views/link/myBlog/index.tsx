const MyBlog = () => {
	return (
		<div className="card content-box">
			<span className="text">
				MyBlog ：
				<a href="http://www.spicyboy.cn" target="_blank" rel="noreferrer">
					http://www.spicyboy.cn
				</a>{" "}
				🍒🍉🍊
			</span>
		</div>
	);
};

export default MyBlog;
