import { useState } from "react";
import UseEffectTest from "./components/UseEffectTest";
import UseTransition from "./components/UseTransition";
import Context from "./components/Context";
import UseImperativeHandle from "./components/UseImperativeHandle/UseImperativeHandle";
import Fu from "./components/forwardRef/Fu";
import { Button } from "antd";
import "./index.less";

const UseComponent = () => {

	const typeList = ['useEffect', 'forwardRef', 'useImperativeHandle', 'Context', 'UseTransition'];
	const [type, setType] = useState('');

	return (
		<div className="card content-box">
			<span className="text">test Hooks 🍓🍇🍈🍉</span>
			<div>
				{
					typeList.map((item) => {
						return <Button onClick={() => setType(item)} key={item}>{item}</Button>
					})
				}
			</div>
			{type == 'useEffect' && <UseEffectTest />}
			{type == 'forwardRef' && <Fu />}
			{type == 'useImperativeHandle' && <UseImperativeHandle />}
			{type == 'Context' && <Context />}
			{type == 'UseTransition' && <UseTransition />}
		</div>
	);

};

export default UseComponent;
