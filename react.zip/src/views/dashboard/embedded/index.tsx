import "./index.less";

const Embedded = () => {
	return <iframe src="https://cn.bing.com/" frameBorder="0" className="card full-iframe"></iframe>;
};

export default Embedded;
