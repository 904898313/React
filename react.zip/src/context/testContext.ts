import { createContext } from "react";

export const testContext1 = createContext(1);
export const testContext2 = createContext('2');
